#!/bin/sh
exec ./system-ipkg.sh
